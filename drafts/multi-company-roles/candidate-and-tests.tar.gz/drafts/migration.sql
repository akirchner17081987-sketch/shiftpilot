-- Group existing, independently authorized invitations under one personal link.
-- This is staged for QA; it does not activate the feature in production.
create table if not exists private.multi_company_invitation_groups (
  token_hash text primary key check (token_hash ~ '^[0-9a-f]{64}$'),
  email text not null,
  entries jsonb not null,
  expires_at timestamptz not null,
  created_by uuid not null references auth.users(id),
  claimed_by uuid references auth.users(id),
  claimed_at timestamptz
);
alter table private.multi_company_invitation_groups enable row level security;
revoke all on private.multi_company_invitation_groups from public, anon, authenticated;

create or replace function private.manager_multi_invite_options()
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'Nicht berechtigt' using errcode='42501'; end if;
 perform private.sf_assert_aal2('manager_multi_invite_options');
 select coalesce(jsonb_agg(jsonb_build_object('company_id',c.id,'company_name',c.name,
   'can_invite_admin',m.role='OWNER' and m.access_role='OWNER',
   'employees',coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',concat_ws(', ',e.last_name,e.first_name),'email',e.email) order by e.last_name,e.first_name,e.id)
      from public.employees e where e.company_id=c.id and e.status='active' and e.deleted_at is null and e.auth_user_id is null),'[]'::jsonb)) order by c.name,c.id),'[]'::jsonb)
 into result from public.company_members m join public.companies c on c.id=m.company_id
 where m.user_id=auth.uid() and m.status='ACTIVE' and m.role in ('OWNER','ADMIN') and m.access_role in ('OWNER','ADMIN');
 return result;
end $$;

create or replace function private.manager_create_multi_access_invite(p_source uuid,p_email text,p_targets jsonb,p_token_hash text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t jsonb; company uuid; actor text; role_ text; emp uuid; subhash text; created jsonb; anchor jsonb; entries_ jsonb:='[]'::jsonb; seen uuid[]:='{}'; mail text:=lower(trim(coalesce(p_email,'')));
begin
 if auth.uid() is null or not private.can_manage_company_users(p_source) then raise exception 'Nicht berechtigt' using errcode='42501'; end if;
 if jsonb_typeof(p_targets)<>'array' or jsonb_array_length(p_targets)<1 or jsonb_array_length(p_targets)>30 or p_token_hash !~ '^[0-9a-f]{64}$' then raise exception 'Ungültige Unternehmensauswahl'; end if;
 -- Sort lock acquisition consistently to avoid deadlocks. The source row remains the anchor for the email.
 for t in select value from jsonb_array_elements(p_targets) order by (value->>'company_id')::uuid loop
  company:=(t->>'company_id')::uuid; role_:=t->>'role'; emp:=nullif(t->>'employee_id','')::uuid;
  if company is null or company=any(seen) or role_ not in ('EMPLOYEE','TEAM_LEAD','ADMIN') or not private.can_manage_company_users(company) then raise exception 'Unternehmen oder Rolle nicht berechtigt' using errcode='42501'; end if;
  seen:=array_append(seen,company);
  select m.role into actor from public.company_members m where m.company_id=company and m.user_id=auth.uid() and m.status='ACTIVE' and m.access_role in ('OWNER','ADMIN');
  if role_='ADMIN' and actor<>'OWNER' then raise exception 'Nur der Inhaber darf Administratoren einladen' using errcode='42501'; end if;
  subhash:=case when company=p_source then p_token_hash else encode(extensions.digest(p_token_hash||':'||company::text,'sha256'),'hex') end;
  created:=private.manager_create_access_invite(company,mail,role_,'{}'::text[],subhash,emp);
  entries_:=entries_||jsonb_build_array(jsonb_build_object('company_id',company,'id',created->>'id','kind',created->>'parameter','hash',subhash));
  if company=p_source then anchor:=created; end if;
 end loop;
 if anchor is null then raise exception 'Das aktuelle Unternehmen muss ausgewählt sein'; end if;
 insert into private.multi_company_invitation_groups(token_hash,email,entries,expires_at,created_by)
 values(p_token_hash,mail,entries_,now()+interval '7 days',auth.uid());
 return anchor;
end $$;

create or replace function public.manager_multi_invite_options() returns jsonb language sql stable security invoker set search_path='' as $$select private.manager_multi_invite_options()$$;
create or replace function public.manager_create_multi_access_invite(p_source uuid,p_email text,p_targets jsonb,p_token_hash text) returns jsonb language sql security invoker set search_path='' as $$select private.manager_create_multi_access_invite(p_source,p_email,p_targets,p_token_hash)$$;
revoke all on function private.manager_multi_invite_options(),private.manager_create_multi_access_invite(uuid,text,jsonb,text),public.manager_multi_invite_options(),public.manager_create_multi_access_invite(uuid,text,jsonb,text) from public,anon;
grant execute on function private.manager_multi_invite_options(),private.manager_create_multi_access_invite(uuid,text,jsonb,text),public.manager_multi_invite_options(),public.manager_create_multi_access_invite(uuid,text,jsonb,text) to authenticated;

-- A switch is a presentation choice only; each target is still authorized server-side.
create or replace function private.multi_role_company_options()
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'Nicht angemeldet' using errcode='42501'; end if;
 select coalesce(jsonb_agg(to_jsonb(q) order by q.company_name,q.company_id,q.mode),'[]'::jsonb) into result from (
  select c.id company_id,c.name company_name,'manager'::text mode,m.role role
  from public.company_members m join public.companies c on c.id=m.company_id
  where m.user_id=auth.uid() and m.status='ACTIVE'
  union all
  select c.id,c.name,'employee'::text,'EMPLOYEE'::text
  from public.employees e join public.companies c on c.id=e.company_id
  where e.auth_user_id=auth.uid() and e.status='active' and e.deleted_at is null and e.access_status='ACTIVE'
  and not private.sf_has_time_only_login()
  and not exists(select 1 from public.company_members m where m.company_id=e.company_id and m.user_id=auth.uid()
    and (m.status<>'ACTIVE' or m.role in ('VIEWER','TIME_TRACKING') or 'read_only'=any(m.extra_permissions)))
 ) q;
 return result;
end $$;
create or replace function public.multi_role_company_options() returns jsonb language sql stable security invoker set search_path='' as $$select private.multi_role_company_options()$$;
revoke all on function private.multi_role_company_options(),public.multi_role_company_options() from public,anon;
grant execute on function private.multi_role_company_options(),public.multi_role_company_options() to authenticated;

create or replace function private.handle_multi_company_invitation_signup()
returns trigger language plpgsql security definer set search_path='' as $$
declare raw text; hash_ text; g private.multi_company_invitation_groups%rowtype; item jsonb; ci public.company_member_invites%rowtype; ei public.employee_access_invites%rowtype; company uuid; invite_id uuid; hash_expected text;
begin
 raw:=coalesce(nullif(new.raw_user_meta_data->>'sf_company_invite',''),nullif(new.raw_user_meta_data->>'sf_employee_invite',''));
 if raw is null then return new; end if;
 hash_:=encode(extensions.digest(raw,'sha256'),'hex');
 select * into g from private.multi_company_invitation_groups where token_hash=hash_ for update;
 if not found then return new; end if;
 if g.claimed_at is not null or g.expires_at<=now() or lower(coalesce(new.email,''))<>g.email then raise exception 'Die gemeinsame Einladung ist ungültig oder abgelaufen'; end if;
 for item in select value from jsonb_array_elements(g.entries) order by value->>'company_id' loop
  company:=(item->>'company_id')::uuid; invite_id:=(item->>'id')::uuid; hash_expected:=item->>'hash';
  if item->>'kind'='employeeInvite' then
   select * into ei from public.employee_access_invites where id=invite_id and company_id=company and token_hash=hash_expected and lower(email)=g.email and expires_at>now() for update;
   if not found then raise exception 'Ein Mitarbeiterzugang der Einladung ist nicht mehr verfügbar'; end if;
   if hash_expected=hash_ then
    if ei.claimed_by is distinct from new.id or ei.claimed_at is null then raise exception 'Einladungszugang wurde nicht bestätigt'; end if;
   else
    if ei.claimed_at is not null then raise exception 'Mitarbeitereinladung bereits verwendet'; end if;
    update public.employees set auth_user_id=new.id,access_status='ACTIVE',access_linked_at=now(),updated_at=now() where id=ei.employee_id and company_id=company and status='active' and deleted_at is null and (auth_user_id is null or auth_user_id=new.id);
    if not found then raise exception 'Mitarbeiterprofil nicht verfügbar'; end if;
    update public.employee_access_invites set claimed_at=now(),claimed_by=new.id where id=ei.id;
   end if;
  elsif item->>'kind'='teamInvite' then
   select * into ci from public.company_member_invites where id=invite_id and company_id=company and token_hash=hash_expected and lower(email)=g.email and expires_at>now() for update;
   if not found then raise exception 'Ein Teamzugang der Einladung ist nicht mehr verfügbar'; end if;
   if hash_expected=hash_ then
    if ci.claimed_by is distinct from new.id or ci.status<>'CLAIMED' then raise exception 'Einladungszugang wurde nicht bestätigt'; end if;
   else
    if ci.status<>'INVITED' then raise exception 'Teameinladung ist nicht mehr aktiv'; end if;
    insert into public.company_members(company_id,user_id,role,status,access_role,extra_permissions) values(ci.company_id,new.id,ci.role,'ACTIVE',ci.access_role,ci.extra_permissions);
    if ci.employee_id is not null then
     update public.employees set auth_user_id=new.id,access_status='ACTIVE',access_linked_at=now(),updated_at=now() where id=ci.employee_id and company_id=company and auth_user_id is null and status='active' and deleted_at is null;
     if not found then raise exception 'Mitarbeiterprofil nicht verfügbar'; end if;
    end if;
    update public.company_member_invites set status='CLAIMED',claimed_by=new.id,claimed_at=now() where id=ci.id;
   end if;
  else raise exception 'Ungültige Einladungsart'; end if;
 end loop;
 update private.multi_company_invitation_groups set claimed_by=new.id,claimed_at=now() where token_hash=hash_;
 return new;
end $$;
revoke all on function private.handle_multi_company_invitation_signup() from public,anon,authenticated;
drop trigger if exists zz_schichtfunk_multi_company_signup on auth.users;
create trigger zz_schichtfunk_multi_company_signup after insert on auth.users for each row execute function private.handle_multi_company_invitation_signup();
