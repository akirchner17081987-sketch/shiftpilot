\set ON_ERROR_STOP on
insert into public.employees(id,company_id,first_name,last_name,email) values ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','QA','Zweite','second@example.invalid') on conflict(id) do nothing;
select set_config('request.user','11111111-1111-1111-1111-111111111111',false);
select set_config('request.aal','aal1',false);
do $$begin
 begin perform private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','second@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02"}]'::jsonb,repeat('a',64)); raise exception 'unexpected MFA bypass';
 exception when raise_exception then if sqlerrm<>'MFA_REQUIRED' then raise; end if; end;
end$$;
select set_config('request.aal','aal2',false);
do $$begin
 begin perform private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','second@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02"},{"company_id":"cccccccc-cccc-cccc-cccc-cccccccccccc","role":"ADMIN"}]'::jsonb,repeat('b',64)); raise exception 'unexpected unauthorized company';
 exception when insufficient_privilege then null; end;
end$$;
update public.company_members set role='ADMIN',access_role='ADMIN' where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='11111111-1111-1111-1111-111111111111';
do $$begin
 begin perform private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','second@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,repeat('c',64)); raise exception 'unexpected admin escalation';
 exception when insufficient_privilege then null; end;
end$$;
update public.company_members set role='OWNER',access_role='OWNER' where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='11111111-1111-1111-1111-111111111111';
do $$declare h text:=encode(extensions.digest('revoked-raw-token','sha256'),'hex');
begin
 perform private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','second@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,h);
end$$;
update public.company_member_invites set status='REVOKED' where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and email='second@example.invalid';
do $$begin
 begin insert into auth.users(id,email,raw_user_meta_data) values('33333333-3333-3333-3333-333333333333','second@example.invalid','{"sf_employee_invite":"revoked-raw-token"}'); raise exception 'unexpected revoked invitation success';
 exception when raise_exception then if sqlerrm<>'Teameinladung ist nicht mehr aktiv' then raise; end if; end;
 if exists(select 1 from auth.users where id='33333333-3333-3333-3333-333333333333') then raise exception 'user exists after failed signup'; end if;
 if exists(select 1 from public.employees where id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeee02' and auth_user_id is not null) then raise exception 'partial employee activation'; end if;
end$$;
select 'PASS: MFA, company authorization, owner-only admin, revoked invitation atomicity' as result;
