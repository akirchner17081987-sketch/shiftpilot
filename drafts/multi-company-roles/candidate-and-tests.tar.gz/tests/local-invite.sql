\set ON_ERROR_STOP on
insert into auth.users(id,email) values ('11111111-1111-1111-1111-111111111111','manager@example.invalid');
insert into public.companies values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','Firma A'),('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','Firma B'),('cccccccc-cccc-cccc-cccc-cccccccccccc','Firma C');
insert into public.company_members values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','11111111-1111-1111-1111-111111111111','OWNER','ACTIVE','OWNER','{}'),('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','11111111-1111-1111-1111-111111111111','OWNER','ACTIVE','OWNER','{}');
insert into public.employees(id,company_id,first_name,last_name,email) values ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','QA','Person','new@example.invalid');
select set_config('request.user','11111111-1111-1111-1111-111111111111',false),set_config('request.aal','aal2',false);
do $$declare h text:=encode(extensions.digest('correct-raw-invitation','sha256'),'hex'); d jsonb;
begin
 d:=private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','new@example.invalid',
 '[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,h);
 if d->>'parameter'<>'employeeInvite' then raise exception 'wrong anchor'; end if;
end$$;
insert into auth.users(id,email,raw_user_meta_data) values ('22222222-2222-2222-2222-222222222222','new@example.invalid','{"sf_employee_invite":"correct-raw-invitation"}');
do $$begin
 if not exists(select 1 from public.employees where id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee' and auth_user_id='22222222-2222-2222-2222-222222222222' and access_status='ACTIVE') then raise exception 'employee not activated'; end if;
 if not exists(select 1 from public.company_members where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='22222222-2222-2222-2222-222222222222' and role='ADMIN' and access_role='ADMIN' and status='ACTIVE') then raise exception 'admin not activated'; end if;
 if exists(select 1 from public.company_members where company_id='cccccccc-cccc-cccc-cccc-cccccccccccc' and user_id='22222222-2222-2222-2222-222222222222') then raise exception 'unselected company granted'; end if;
end$$;
select 'PASS: one invite created employee A and admin B only' as result;
