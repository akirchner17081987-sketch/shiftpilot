const { chromium } = require('@playwright/test');
const fs = require('node:fs');
const assert = require('node:assert/strict');

(async () => {
 const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
 try {
  const page = await browser.newPage();
  await page.route('https://qa.example.test/', r => r.fulfill({ contentType: 'text/html', body: '<html><body><div id="host"></div></body></html>' }));
  await page.goto('https://qa.example.test/');
  await page.evaluate(() => {
   window.__calls = [];
   window.SFBackend = {
    role: 'OWNER', companyId: 'a', ready: true, __sfMultiRoleInvitesReady: true,
    init: async () => {}, client: {
     rpc: async (name, args) => {
      window.__calls.push({ name, args });
      if (name === 'manager_list_access_users') return { data: { users: [], employees: [], personnel_employees: [] } };
      if (name === 'manager_multi_invite_options') return { data: [
       { company_id: 'a', company_name: 'Firma A', can_invite_admin: true, employees: [{ id: 'employee-a', name: 'Test, Person', email: 'person@example.invalid' }] },
       { company_id: 'b', company_name: 'Firma B', can_invite_admin: true, employees: [] },
       { company_id: 'c', company_name: 'Firma C', can_invite_admin: false, employees: [] }
      ] };
      if (name === 'manager_create_multi_access_invite') return { data: { id: 'invite', parameter: 'employeeInvite' } };
      return { data: null };
     },
     functions: { invoke: async () => ({ error: null }) }
    }
   };
  });
  await page.addScriptTag({ content: fs.readFileSync(process.argv[2], 'utf8') });
  await page.evaluate(() => SFBackend.renderUserManagement(document.querySelector('#host')));
  await page.locator('#sfInviteUser').click();
  await page.locator('[data-multi-company="b"]').waitFor();
  assert.equal(await page.locator('[data-multi-company="a"] [data-company-enabled]').isDisabled(), true);
  await page.locator('#sfInviteEmail').fill('person@example.invalid');
  await page.locator('[data-multi-company="a"] [data-company-employee]').selectOption('employee-a');
  await page.locator('[data-multi-company="b"] [data-company-enabled]').check();
  await page.locator('[data-multi-company="b"] [data-company-role]').selectOption('ADMIN');
  assert.equal(await page.locator('[data-multi-company="c"] option[value="ADMIN"]').count(), 0);
  await page.locator('#sfCreateTeamInvite').click();
  await page.getByText('Link sicher weitergeben').waitFor();
  const calls = await page.evaluate(() => window.__calls);
  const create = calls.find(x => x.name === 'manager_create_multi_access_invite');
  assert.deepEqual(create.args.p_targets, [
   { company_id: 'a', role: 'EMPLOYEE', employee_id: 'employee-a' },
   { company_id: 'b', role: 'ADMIN', employee_id: null }
  ]);
  assert.equal(create.args.p_source, 'a');
  assert.equal(create.args.p_email, 'person@example.invalid');
  assert.match(create.args.p_token_hash, /^[a-f0-9]{64}$/);
  console.log('PASS: one invite selects company-specific employee and administrator roles');
 } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
