const { chromium } = require('@playwright/test');
const fs = require('node:fs');
const assert = require('node:assert/strict');

(async () => {
 const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
 try {
  const manager = await browser.newPage();
  await manager.route('https://qa.example.test/**', r => r.fulfill({ contentType: 'text/html', body: '<html><body><button class="company-card"><span class="company-icon"></span><b>Firma A</b></button></body></html>' }));
  await manager.goto('https://qa.example.test/#app');
  await manager.evaluate(() => {
   window.SFBackend = {
    user: { id: 'u' }, ready: true, role: 'OWNER', companyId: 'a', __sfMultiRoleInvitesReady: true,
    updateState: () => {}, client: {
     from(name) {
      const q = { select: () => q, eq: () => q, single: async () => ({ data: { id: 'a', name: 'Firma A' } }),
       then: resolve => resolve({ data: [{ company_id: 'a', role: 'OWNER', status: 'ACTIVE' }] }) };
      return q;
     },
     rpc: async name => name === 'company_switcher_groups' ? { data: [] } : { data: window.__revoke ? [] : [
      { company_id: 'a', company_name: 'Firma A', mode: 'manager', role: 'OWNER' },
      { company_id: 'b', company_name: 'Firma B', mode: 'employee', role: 'EMPLOYEE' }
     ] }
    }
   };
  });
  await manager.addScriptTag({ content: fs.readFileSync(process.argv[2], 'utf8') });
  await manager.locator('button.company-card').click();
  await manager.evaluate(()=>window.__revoke=true);
  await manager.locator('[data-company="b"][data-mode="employee"]').click();
  await manager.getByText('Für dieses Unternehmen besteht kein aktiver Zugang.').waitFor();
  await manager.evaluate(()=>window.__revoke=false);
  await manager.locator('[data-company="b"][data-mode="employee"]').click();
  await manager.waitForURL('**/?bereich=mitarbeiter#app');
  assert.equal(await manager.evaluate(() => sessionStorage.getItem('sfEmployeeCompany:u')), 'b');
  console.log('PASS: manager switches to the employee portal');

  const employee = await browser.newPage();
  await employee.route('https://qa.example.test/**', r => r.fulfill({ contentType: 'text/html', body: '<html><body></body></html>' }));
  await employee.goto('https://qa.example.test/?bereich=mitarbeiter#app');
  await employee.evaluate(() => {
   window.SFBackend = {
    user: { id: 'u' }, ready: true, role: 'EMPLOYEE', companyId: 'b', employeeDbId: 'eb',
    __sfEmployeeMultiCompanyReady: true, __sfMultiRoleInvitesReady: true, __sfMultiEmployee: true,
    __sfEmployeeOptions: [{ company_id: 'b', company_name: 'Firma B', employee_id: 'eb' }],
    ensureCompany: async () => {}, hydrateEmployee: async () => {},
    openEmployeePortal() { document.querySelector('#sfEmployeePortal')?.remove(); const el = document.createElement('div'); el.id = 'sfEmployeePortal'; document.body.append(el); },
    client: { rpc: async () => ({ data: window.__revoke ? [] : [{ company_id: 'a', company_name: 'Firma A', mode: 'manager', role: 'ADMIN' }] }) }
   };
  });
  await employee.addScriptTag({ content: fs.readFileSync(process.argv[3], 'utf8') });
  await employee.evaluate(() => SFBackend.openEmployeePortal());
  await employee.locator('#sfEmployeeCompanySelect option[value="manager:a"]').waitFor({ state: 'attached' });
  await employee.evaluate(()=>window.__revoke=true);
  await employee.locator('#sfEmployeeCompanySelect').selectOption('manager:a');
  await employee.getByText('Dieser Verwaltungszugang ist nicht mehr freigegeben.').waitFor();
  await employee.evaluate(()=>window.__revoke=false);
  await employee.locator('#sfEmployeeCompanySelect').selectOption('manager:a');
  await employee.waitForURL('https://qa.example.test/#app');
  assert.equal(await employee.evaluate(() => sessionStorage.getItem('sf_active_company_v1:u')), 'a');
  console.log('PASS: employee switches to the authorized management role');
 } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
