\set ON_ERROR_STOP on
insert into public.employees(id,company_id,first_name,last_name,email) values('eeeeeeee-eeee-eeee-eeee-eeeeeeeeee05','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','QA','Erneuerung','renew@example.invalid') on conflict(id) do nothing;
select set_config('request.user','11111111-1111-1111-1111-111111111111',false),set_config('request.aal','aal2',false);
select private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','renew@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee05"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,encode(extensions.digest(repeat('c',72),'sha256'),'hex'));
do $$declare id_ uuid; snapshot jsonb;begin
 select id into id_ from public.employee_access_invites where employee_id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeee05';
 snapshot:=private.manager_multi_invite_snapshot('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',id_);
 if jsonb_array_length(snapshot->'targets')<>2 or snapshot->>'email'<>'renew@example.invalid' then raise exception 'missing snapshot'; end if;
 begin perform private.manager_renew_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',id_,'renew@example.invalid','[{"company_id":"cccccccc-cccc-cccc-cccc-cccccccccccc","role":"ADMIN"}]'::jsonb,repeat('d',64));raise exception 'invalid renewal allowed'; exception when insufficient_privilege then null;end;
 if not exists(select 1 from private.multi_company_invitation_groups where email='renew@example.invalid') or not exists(select 1 from public.employee_access_invites where id=id_) then raise exception 'failed renewal cancelled previous invite';end if;
 perform private.manager_renew_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',id_,'renew@example.invalid',snapshot->'targets',encode(extensions.digest(repeat('d',72),'sha256'),'hex'));
 if exists(select 1 from private.multi_company_invitation_groups where token_hash=encode(extensions.digest(repeat('c',72),'sha256'),'hex')) or not exists(select 1 from private.multi_company_invitation_groups where token_hash=encode(extensions.digest(repeat('d',72),'sha256'),'hex')) then raise exception 'wrong renewal'; end if;
end$$;
insert into auth.users(id,email,raw_user_meta_data) values('66666666-6666-6666-6666-666666666666','renew@example.invalid',jsonb_build_object('sf_employee_invite',repeat('d',72)));
do $$begin if not exists(select 1 from public.company_members where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='66666666-6666-6666-6666-666666666666' and role='ADMIN') then raise exception 'renewed roles absent';end if;end$$;
select 'PASS: renewal preserves roles and rolls back on invalid target' result;