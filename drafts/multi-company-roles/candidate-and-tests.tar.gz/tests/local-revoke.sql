\set ON_ERROR_STOP on
insert into public.employees(id,company_id,first_name,last_name,email) values('eeeeeeee-eeee-eeee-eeee-eeeeeeeeee04','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','QA','Rueckzug','cancel@example.invalid');
select set_config('request.user','11111111-1111-1111-1111-111111111111',false),set_config('request.aal','aal2',false);
select private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','cancel@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee04"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,encode(extensions.digest(repeat('b',72),'sha256'),'hex'));
update public.company_members set role='ADMIN',access_role='ADMIN' where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='11111111-1111-1111-1111-111111111111';
do $$declare id_ uuid;begin select id into id_ from public.employee_access_invites where employee_id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeee04'; begin perform private.manager_revoke_multi_or_single_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',id_);raise exception 'admin escalation';exception when insufficient_privilege then null;end;
if not exists(select 1 from public.employee_access_invites where id=id_) then raise exception 'partial revocation';end if;end$$;
update public.company_members set role='OWNER',access_role='OWNER' where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='11111111-1111-1111-1111-111111111111';
do $$declare id_ uuid;begin select id into id_ from public.employee_access_invites where employee_id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeee04';perform private.manager_revoke_multi_or_single_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',id_);
if exists(select 1 from public.employee_access_invites where id=id_) or not exists(select 1 from public.company_member_invites where email='cancel@example.invalid' and status='REVOKED') or exists(select 1 from private.multi_company_invitation_groups where email='cancel@example.invalid') then raise exception 'group not revoked';end if;end$$;
select 'PASS: grouped revoke is atomic and owner-protected' result;
