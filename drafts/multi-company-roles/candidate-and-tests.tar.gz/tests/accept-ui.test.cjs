const {chromium}=require('@playwright/test');const fs=require('fs');const assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({headless:true,args:['--no-sandbox']});try{const p=await b.newPage();p.setDefaultTimeout(8000);await p.route('https://qa.example.test/**',r=>r.fulfill({contentType:'text/html',body:'<html><body></body></html>'}));const token='a'.repeat(72);await p.goto('https://qa.example.test/?teamInvite='+token);
await p.evaluate(()=>{window.calls=[];window.SFBackend={__sfMultiRoleInvitesReady:true,client:{rpc:async(name,args)=>{window.calls.push({name,args});return {data:{companies:2}}}},ensureCompany:async()=>{},hydrateEmployee:async()=>{},openEmployeePortal:()=>{},boot:async function(){this.ready=true;this.user={id:'user'}}}});
await p.addScriptTag({content:fs.readFileSync('/vercel/sandbox/shiftpilot/sfqa-employee.js','utf8')});
await p.evaluate(()=>SFBackend.boot());await p.locator('#sfMultiInviteAccept [data-accept]').click();
await p.waitForURL('https://qa.example.test/#app');
console.log('PASS: signed-in account can accept group invite and remove token from address');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});