const {chromium}=require('@playwright/test');const fs=require('fs');
(async()=>{let b=await chromium.launch({headless:true,args:['--no-sandbox']});try{let p=await b.newPage();p.setDefaultTimeout(5000);
await p.route('https://qa.example.test/**',r=>r.fulfill({contentType:'text/html',body:'<html><body></body></html>'}));await p.goto('https://qa.example.test/?teamInvite=abc');
await p.evaluate(()=>{window.SFBackend={__sfMultiRoleInvitesReady:true,init:async()=>{},authDialog:type=>window.__auth=type}});
await p.addScriptTag({content:fs.readFileSync('/tmp/sfqa-multi-admin.js','utf8')});await p.evaluate(()=>SFBackend.showTeamInvitation('abc'));
await p.getByText('Ich habe bereits ein Konto').click();await p.waitForFunction(()=>window.__auth==='login');console.log('PASS: team invite offers existing-account login');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});