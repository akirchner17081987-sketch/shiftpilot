\set ON_ERROR_STOP on
insert into auth.users(id,email,email_confirmed_at) values('44444444-4444-4444-4444-444444444444','existing@example.invalid',null),('55555555-5555-5555-5555-555555555555','wrong@example.invalid',now());
insert into public.employees(id,company_id,first_name,last_name,email) values('eeeeeeee-eeee-eeee-eeee-eeeeeeeeee03','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','QA','Bestand','existing@example.invalid');
select set_config('request.user','11111111-1111-1111-1111-111111111111',false),set_config('request.aal','aal2',false);
select private.manager_create_multi_access_invite('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','existing@example.invalid','[{"company_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"EMPLOYEE","employee_id":"eeeeeeee-eeee-eeee-eeee-eeeeeeeeee03"},{"company_id":"bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb","role":"ADMIN"}]'::jsonb,encode(extensions.digest(repeat('a',72),'sha256'),'hex'));
select set_config('request.user','44444444-4444-4444-4444-444444444444',false);
do $$begin begin perform private.claim_multi_company_invite(repeat('a',72)); raise exception 'unconfirmed allowed'; exception when insufficient_privilege then null; end;end$$;
update auth.users set email_confirmed_at=now() where id='44444444-4444-4444-4444-444444444444';
select set_config('request.user','55555555-5555-5555-5555-555555555555',false);
do $$begin begin perform private.claim_multi_company_invite(repeat('a',72)); raise exception 'wrong email allowed'; exception when insufficient_privilege then null; end;end$$;
select set_config('request.user','44444444-4444-4444-4444-444444444444',false);
select private.claim_multi_company_invite(repeat('a',72));
do $$begin if not exists(select 1 from public.employees where id='eeeeeeee-eeee-eeee-eeee-eeeeeeeeee03' and auth_user_id='44444444-4444-4444-4444-444444444444') or not exists(select 1 from public.company_members where company_id='bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' and user_id='44444444-4444-4444-4444-444444444444' and role='ADMIN') then raise exception 'roles missing'; end if;
 begin perform private.claim_multi_company_invite(repeat('a',72)); raise exception 'reuse allowed'; exception when insufficient_privilege then null; end;
end$$;
select 'PASS: existing account, confirmed email, denied wrong account and reuse' result;
