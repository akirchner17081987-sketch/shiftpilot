const { chromium }=require('@playwright/test');const fs=require('fs');const assert=require('node:assert/strict');
(async()=>{let b=await chromium.launch({headless:true,args:['--no-sandbox']});try{let p=await b.newPage();p.setDefaultTimeout(8000);
await p.route('https://qa.example.test/',r=>r.fulfill({contentType:'text/html',body:'<html><body><div id="host"></div></body></html>'}));await p.goto('https://qa.example.test/');
await p.evaluate(()=>{window.calls=[];let targets=[{company_id:'a',role:'EMPLOYEE',employee_id:'e-a'},{company_id:'b',role:'ADMIN',employee_id:null}];window.SFBackend={user:{id:'actor'},role:'OWNER',companyId:'a',ready:true,__sfMultiRoleInvitesReady:true,init:async()=>{},client:{
rpc:async(name,args)=>{window.calls.push({name,args});
if(name==='manager_list_access_users')return {data:{users:[{kind:'INVITE',record_id:'invite-a',email:'qa@example.invalid',role:'EMPLOYEE',status:'INVITED',permissions:[],employee_id:'e-a'}],employees:[],personnel_employees:[]}};
if(name==='manager_multi_invite_options')return {data:[{company_id:'a',company_name:'Firma A',can_invite_admin:true,employees:[{id:'e-a',name:'QA Test'}]},{company_id:'b',company_name:'Firma B',can_invite_admin:true,employees:[]}]};
if(name==='manager_multi_invite_snapshot')return {data:{email:'qa@example.invalid',targets}};
if(name==='manager_renew_multi_access_invite')return {data:{id:'new-invite',parameter:'employeeInvite'}};return {data:null}},functions:{invoke:async()=>({error:null})}}}});
await p.addScriptTag({content:fs.readFileSync('/tmp/sfqa-multi-admin.js','utf8')});await p.evaluate(()=>SFBackend.renderUserManagement(document.querySelector('#host')));
await p.locator('[data-new]').click();await p.locator('[data-multi-company="b"]').waitFor();await p.waitForFunction(()=>!document.querySelector('#sfCreateTeamInvite').disabled);
assert.equal(await p.locator('[data-multi-company="b"] [data-company-enabled]').isChecked(),true);
assert.equal(await p.locator('[data-multi-company="b"] [data-company-role]').inputValue(),'ADMIN');
assert.equal(await p.locator('[data-multi-company="a"] [data-company-employee]').inputValue(),'e-a');
assert.equal(await p.locator('#sfInviteEmail').isEditable(),false);
await p.locator('#sfCreateTeamInvite').click();await p.getByText('Link sicher weitergeben').waitFor();
let call=await p.evaluate(()=>calls.find(x=>x.name==='manager_renew_multi_access_invite'));assert.equal(call.args.p_invite_id,'invite-a');assert.equal(call.args.p_targets.length,2);
console.log('PASS: renewal retains employee and administrator selections');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});