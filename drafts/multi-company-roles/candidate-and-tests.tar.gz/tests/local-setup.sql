create role anon; create role authenticated;
create schema auth; create schema private; create schema extensions;
create extension pgcrypto with schema extensions;
create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb,email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.user',true),'')::uuid$$;
create function private.sf_assert_aal2(text) returns void language plpgsql stable as $$begin if current_setting('request.aal',true) is distinct from 'aal2' then raise exception 'MFA_REQUIRED'; end if; end$$;
create table public.companies(id uuid primary key,name text);
create table public.company_members(company_id uuid,user_id uuid,role text,status text,access_role text,extra_permissions text[] default '{}',primary key(company_id,user_id));
create table public.employees(id uuid primary key,company_id uuid,first_name text,last_name text,email text,status text default 'active',deleted_at timestamptz,auth_user_id uuid,access_status text default 'NONE',access_linked_at timestamptz,updated_at timestamptz);
create table public.company_member_invites(id uuid primary key default gen_random_uuid(),company_id uuid,email text,role text,access_role text,extra_permissions text[],employee_id uuid,token_hash text unique,status text,expires_at timestamptz,created_by uuid,created_at timestamptz default now(),claimed_by uuid,claimed_at timestamptz,unique(company_id,email));
create table public.employee_access_invites(id uuid primary key default gen_random_uuid(),company_id uuid,employee_id uuid,email text,token_hash text unique,expires_at timestamptz,created_by uuid,created_at timestamptz default now(),claimed_by uuid,claimed_at timestamptz,unique(company_id,employee_id));
create function private.can_manage_company_users(p_company_id uuid) returns boolean language plpgsql stable security definer set search_path='' as $$begin if auth.uid() is null or not exists(select 1 from public.company_members m where m.company_id=p_company_id and m.user_id=auth.uid() and m.status='ACTIVE' and m.role in ('OWNER','ADMIN') and m.access_role in ('OWNER','ADMIN')) then return false; end if; perform private.sf_assert_aal2('manage_company_users'); return true; end$$;
CREATE OR REPLACE FUNCTION private.manager_create_access_invite(p_company_id uuid, p_email text, p_role text, p_permissions text[], p_token_hash text, p_employee_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare actor text; mail text:=lower(trim(coalesce(p_email,''))); perms text[]:=coalesce(p_permissions,'{}'); eid uuid; ident uuid; backend text;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_company_id::text,7041));
 select role into actor from public.company_members where company_id=p_company_id and user_id=auth.uid() and status='ACTIVE';
 if actor is null or actor not in ('OWNER','ADMIN') then raise exception 'Nicht berechtigt'; end if;
 perform private.sf_assert_aal2('manager_create_access_invite');
 if p_role='ADMIN' and actor<>'OWNER' then raise exception 'Nur der Inhaber darf Administratoren einladen'; end if;
 if p_role is null or p_role not in ('ADMIN','TEAM_LEAD','EMPLOYEE') then raise exception 'Ungültige Rolle'; end if;
 if mail !~ '^[^@[:space:]]+@[^@[:space:]]+[.][^@[:space:]]+$' or coalesce(p_token_hash,'') !~ '^[0-9a-f]{64}$' then raise exception 'Ungültige E-Mail oder Einladungsschlüssel'; end if;
 if exists(select 1 from public.company_members cm join auth.users u on u.id=cm.user_id where cm.company_id=p_company_id and lower(u.email)=mail)
 or exists(select 1 from public.employees e join auth.users u on u.id=e.auth_user_id where e.company_id=p_company_id and lower(u.email)=mail) then raise exception 'Für diese E-Mail besteht bereits ein Benutzer'; end if;
 if p_employee_id is not null then
  select id into eid from public.employees where id=p_employee_id and company_id=p_company_id and deleted_at is null and status='active' and auth_user_id is null for update;
  if eid is null then raise exception 'Mitarbeiterprofil nicht verfügbar'; end if;
 end if;
 if p_role='EMPLOYEE' and cardinality(perms)=0 then
  if eid is null then raise exception 'Bitte das zugehörige Mitarbeiterprofil auswählen'; end if;
  insert into public.employee_access_invites(company_id,employee_id,email,token_hash,expires_at,created_by) values(p_company_id,eid,mail,p_token_hash,now()+interval '7 days',auth.uid())
  on conflict(company_id,employee_id) do update set email=excluded.email,token_hash=excluded.token_hash,expires_at=excluded.expires_at,created_at=now(),created_by=auth.uid(),claimed_at=null,claimed_by=null returning id into ident;
  update public.employees set access_status='INVITED' where id=eid;
  update public.company_member_invites set status='REVOKED' where company_id=p_company_id and email=mail and status in ('INVITED','EXPIRED');
  return jsonb_build_object('id',ident,'parameter','employeeInvite');
 end if;
 backend:=case when p_role='ADMIN' then 'ADMIN' when p_role='EMPLOYEE' then 'TIME_TRACKING' when 'read_only'=any(perms) then 'VIEWER' else 'PLANNER' end;
 insert into public.company_member_invites(company_id,email,role,access_role,extra_permissions,employee_id,token_hash,status,expires_at,created_by)
 values(p_company_id,mail,backend,p_role,perms,eid,p_token_hash,'INVITED',now()+interval '7 days',auth.uid())
 on conflict(company_id,email) do update set role=excluded.role,access_role=excluded.access_role,extra_permissions=excluded.extra_permissions,employee_id=excluded.employee_id,token_hash=excluded.token_hash,status='INVITED',expires_at=excluded.expires_at,created_by=auth.uid(),created_at=now(),claimed_by=null,claimed_at=null returning id into ident;
 -- Replace any outstanding portal invitation for the same address.
 delete from public.employee_access_invites where company_id=p_company_id and lower(email)=mail and claimed_at is null;
 return jsonb_build_object('id',ident,'parameter','teamInvite');
end $function$
;
CREATE OR REPLACE FUNCTION private.handle_schichtfunk_employee_signup()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  v_token text;
  v_hash text;
  v_inv public.employee_access_invites%rowtype;
  v_emp public.employees%rowtype;
begin
  v_token := nullif(new.raw_user_meta_data->>'sf_employee_invite','');
  if v_token is null then
    return new;
  end if;

  v_hash := encode(extensions.digest(v_token, 'sha256'), 'hex');

  select * into v_inv
  from public.employee_access_invites
  where token_hash=v_hash
    and claimed_at is null
    and expires_at>now()
  for update;

  if not found then
    raise exception 'SchichtFunk Mitarbeiter-Einladung ist ungültig oder abgelaufen.';
  end if;

  if lower(v_inv.email) <> lower(coalesce(new.email,'')) then
    raise exception 'Die E-Mail-Adresse passt nicht zur SchichtFunk Mitarbeiter-Einladung.';
  end if;

  select * into v_emp from public.employees where id=v_inv.employee_id for update;
  if not found or v_emp.company_id<>v_inv.company_id then
    raise exception 'Mitarbeiterdatensatz zur Einladung nicht gefunden.';
  end if;
  if v_emp.status<>'active' then
    raise exception 'Der Mitarbeiterzugang ist nicht aktivierbar.';
  end if;
  if v_emp.auth_user_id is not null and v_emp.auth_user_id<>new.id then
    raise exception 'Für diesen Mitarbeiter besteht bereits ein Zugang.';
  end if;

  update public.employees
    set auth_user_id=new.id,
        access_status='ACTIVE',
        access_linked_at=now(),
        updated_at=now()
  where id=v_inv.employee_id;

  update public.employee_access_invites
    set claimed_at=now(), claimed_by=new.id
  where id=v_inv.id;

  return new;
end
$function$
;
CREATE OR REPLACE FUNCTION private.handle_schichtfunk_company_signup()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare v_token text; v_hash text; v_inv public.company_member_invites%rowtype;
begin
  v_token:=coalesce(new.raw_user_meta_data->>'sf_company_invite','');
  if v_token='' then return new; end if;
  v_hash:=encode(extensions.digest(v_token,'sha256'),'hex');
  select * into v_inv from public.company_member_invites where token_hash=v_hash and status='INVITED' and expires_at>now() for update;
  if v_inv.id is null or lower(coalesce(new.email,''))<>lower(v_inv.email) then raise exception 'Ungültige oder abgelaufene Einladung'; end if;
  insert into public.company_members(company_id,user_id,role,status,access_role,extra_permissions) values(v_inv.company_id,new.id,v_inv.role,'ACTIVE',v_inv.access_role,v_inv.extra_permissions)
  on conflict(company_id,user_id) do update set role=excluded.role,status='ACTIVE',access_role=excluded.access_role,extra_permissions=excluded.extra_permissions;
 if v_inv.employee_id is not null then
 update public.employees set auth_user_id=new.id,access_status='ACTIVE',access_linked_at=now() where id=v_inv.employee_id and company_id=v_inv.company_id and auth_user_id is null and status='active' and deleted_at is null;
 if not found then raise exception 'Mitarbeiterprofil nicht verfügbar'; end if;
 end if;
  update public.company_member_invites set status='CLAIMED',claimed_by=new.id,claimed_at=now() where id=v_inv.id;
  return new;
end $function$
;
create trigger on_schichtfunk_company_signup after insert on auth.users for each row execute function private.handle_schichtfunk_company_signup();
create trigger on_schichtfunk_employee_signup after insert on auth.users for each row execute function private.handle_schichtfunk_employee_signup();
